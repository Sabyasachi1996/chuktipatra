-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 15, 2024 at 09:49 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 8.1.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ite_udin_agreement`
--
CREATE DATABASE IF NOT EXISTS `ite_udin_agreement` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ite_udin_agreement`;

-- --------------------------------------------------------

--
-- Table structure for table `agreement_master`
--

DROP TABLE IF EXISTS `agreement_master`;
CREATE TABLE IF NOT EXISTS `agreement_master` (
  `id` int(21) NOT NULL AUTO_INCREMENT,
  `ref_num` varchar(13) NOT NULL,
  `applicant_type` varchar(10) NOT NULL,
  `applicant_user_id` int(21) NOT NULL,
  `co_applicant_type` varchar(10) DEFAULT NULL,
  `co_applicant_user_id` int(21) DEFAULT NULL,
  `witness_1_user_id` int(21) DEFAULT NULL,
  `witness_2_user_id` int(21) DEFAULT NULL,
  `property_type` varchar(2) NOT NULL,
  `property_detail` longtext NOT NULL,
  `property_address` varchar(200) NOT NULL,
  `property_state` varchar(100) NOT NULL,
  `property_city` varchar(100) NOT NULL,
  `property_pin` varchar(6) NOT NULL,
  `contract_detail` longtext DEFAULT NULL,
  `estamp_num` varchar(20) DEFAULT NULL,
  `estamp_amt` decimal(20,2) DEFAULT NULL,
  `estamp_date` datetime DEFAULT NULL,
  `pg_grn` varchar(20) DEFAULT NULL,
  `file_path` varchar(200) DEFAULT NULL,
  `file_size` varchar(100) DEFAULT NULL,
  `quotation_id` varchar(20) DEFAULT NULL,
  `quotation_amount` varchar(20) DEFAULT NULL,
  `transaction_ref` varchar(30) DEFAULT NULL,
  `udin_num` varchar(50) DEFAULT NULL,
  `udin_num_final` varchar(50) DEFAULT NULL,
  `status` smallint(1) NOT NULL DEFAULT 0 COMMENT '0=ESTAMP PURCHASED, \r\n1=CO-SIGNER REQUEST SENT,\r\n2=CO-SIGNER ACCEPTED,\r\n3=WITNESS REQUEST SENT,\r\n4=WITNESS SIGNED PARTIAL,\r\n5=UPLOAD PENDING,\r\n6=PROVISIONAL UDIN GENERATED,\r\n7=CO-APPLICANT REQUEST SENT,\r\n8=CO-APPLICANT SIGNED,\r\n9=WITNESS ONE REQUEST SENT,\r\n10=WITNESS ONE SIGNED,\r\n11=WITNESS TWO REQUEST SENT,\r\n12=CO-SIGNING COMPLETED,\r\n90=UDIN GENERATION IN-PRGRESS,\r\n99=UDIN GENERATED',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estamp_num` (`estamp_num`),
  UNIQUE KEY `pg_grn` (`pg_grn`),
  UNIQUE KEY `udin_num` (`udin_num`),
  UNIQUE KEY `udin_num_final` (`udin_num_final`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agreement_master`
--

INSERT INTO `agreement_master` (`id`, `ref_num`, `applicant_type`, `applicant_user_id`, `co_applicant_type`, `co_applicant_user_id`, `witness_1_user_id`, `witness_2_user_id`, `property_type`, `property_detail`, `property_address`, `property_state`, `property_city`, `property_pin`, `contract_detail`, `estamp_num`, `estamp_amt`, `estamp_date`, `pg_grn`, `file_path`, `file_size`, `quotation_id`, `quotation_amount`, `transaction_ref`, `udin_num`, `udin_num_final`, `status`, `created_at`) VALUES
(1, '1704356349004', 'lessor', 1, 'lessee', 2, 3, 4, 'R', '{\"property_type\":\"R\",\"property_floor\":\"7\",\"property_room\":\"3 BHK\",\"property_bed\":\"3\",\"property_bath\":\"2\",\"property_balcony\":\"2\",\"property_area\":\"1234\",\"property_parking\":\"YES\"}', 'GANAPATI PARK AH 51 KRISHNAPUR', 'WEST BENGAL', 'KOLKATA', '700102', '{\"agreement_start\":\"2024-01-01\",\"agreement_duraion\":\"11 MONTHS\",\"rent_pay_day\":\"5\",\"rent_amount\":\"15000\",\"maintenance_amount\":\"3000\",\"security_amount\":\"30000\",\"notice_period\":\"2 MONTHS\",\"estamp_amt\":\"100\"}', '192023245553141478', 100.00, '2024-04-01 13:49:44', '192023245553141478', 'upload/1704356349004.pdf', '82224', 'J3GFMDCZ6335BDZNF9P2', '200', 'S4C5DFYSJRMXTQ', '24-M-SA001207-A-1704395079310', NULL, 90, '2024-01-04 13:49:09'),
(2, '1704446022736', 'lessor', 4, 'lessee', 1, 3, 2, 'R', '{\"property_type\":\"R\",\"property_floor\":\"3\",\"property_room\":\"3 BHK\",\"property_bed\":\"3\",\"property_bath\":\"2\",\"property_balcony\":\"1\",\"property_area\":\"789\",\"property_parking\":\"YES\"}', 'ABASBARI TAMLUK', 'WEST BENGAL', 'TAMLUK', '721636', '{\"agreement_start\":\"2024-02-01\",\"agreement_duraion\":\"23 MONTHS\",\"rent_pay_day\":\"5\",\"rent_amount\":\"10000\",\"maintenance_amount\":\"500\",\"security_amount\":\"20000\",\"notice_period\":\"2 MONTHS\",\"estamp_amt\":\"100\"}', '192023245553147268', 100.00, '2024-05-01 14:45:29', '192023245553147268', 'upload/1704446022736.pdf', '82164', 'M2GKM7VQ69PSZYJR23SK', '200', 'S3DNW6RXQ4YVZB', '24-M-SA001185-A-1704448240715', NULL, 99, '2024-01-05 14:43:42'),
(3, '1704692878582', 'lessor', 5, NULL, 1, 3, 4, 'R', '{\"property_type\":\"R\",\"property_floor\":\"5\",\"property_room\":\"2 BHK\",\"property_bed\":\"2\",\"property_bath\":\"2\",\"property_balcony\":\"1\",\"property_area\":\"678\",\"property_parking\":\"NO\"}', 'SHRISTI APARTMENT JORAKHANA KESTOPUR', 'WEST BENGAL', 'KOLKATA', '700102', '{\"agreement_start\":\"2024-01-15\",\"agreement_duraion\":\"24 MONTHS\",\"rent_pay_day\":\"10\",\"rent_amount\":\"7500\",\"maintenance_amount\":\"500\",\"security_amount\":\"15000\",\"notice_period\":\"1 MONTH\",\"estamp_amt\":\"100\"}', '192023245553152328', 100.00, '2024-01-08 11:19:03', '192023245553152328', 'upload/1704692878582.pdf', '162083', 'HSNXPS4K34TMW9W9KZSQ', '300', 'SFQSVGM3MCBSNJ', '24-M-SA000005-A-1704693985956', NULL, 99, '2024-01-08 11:17:58'),
(4, '1704694607491', 'lessor', 1, NULL, 5, 6, 2, 'R', '{\"property_type\":\"R\",\"property_floor\":\"6\",\"property_room\":\"3 BHK\",\"property_bed\":\"3\",\"property_bath\":\"2\",\"property_balcony\":\"1\",\"property_area\":\"1000\",\"property_parking\":\"YES\"}', 'GANAPATI PARK AH 51 KRISHNAPUR', 'WEST BENGAL', 'KOLKATA', '700102', '{\"agreement_start\":\"2024-01-01\",\"agreement_duraion\":\"11 MONTHS\",\"rent_pay_day\":\"5\",\"rent_amount\":\"10000\",\"maintenance_amount\":\"1000\",\"security_amount\":\"20000\",\"notice_period\":\"1 MONTH\",\"estamp_amt\":\"100\"}', '192023245553152478', 100.00, '2024-01-08 11:48:06', '192023245553152478', 'upload/1704694607491.pdf', '162459', 'HKJ68PRFGDTDGTNPVM9J', '200', 'SSPBHGVYDPFGSP', '24-M-SA001207-A-1704696499913', NULL, 99, '2024-01-08 11:46:47'),
(5, '1704886044690', 'lessor', 1, NULL, 7, 8, NULL, 'R', '{\"property_type\":\"R\",\"property_floor\":\"4\",\"property_room\":\"2 BHK\",\"property_bed\":\"2\",\"property_bath\":\"2\",\"property_balcony\":\"1\",\"property_area\":\"566\",\"property_parking\":\"NO\"}', 'SHRISTI APARTMENT JORAKHANA KESTOPUR', 'WEST BENGAL', 'KOLKATA', '700102', '{\"agreement_start\":\"2024-01-15\",\"agreement_duraion\":\"11 MONTHS\",\"rent_pay_day\":\"5\",\"rent_amount\":\"7500\",\"maintenance_amount\":\"500\",\"security_amount\":\"15000\",\"notice_period\":\"2 MONTHS\",\"estamp_amt\":\"100\"}', '192023245553154558', 100.00, '2024-01-10 16:58:20', '192023245553154558', 'upload/1704886044690.pdf', '787515', '67ZZ5JVS9D9CCNQSJPD4', '200', 'SW9W5BP5QSM8RV', '24-P-SA001207-A-1704888697300', NULL, 9, '2024-01-10 16:57:24');

-- --------------------------------------------------------

--
-- Table structure for table `cosign_requests`
--

DROP TABLE IF EXISTS `cosign_requests`;
CREATE TABLE IF NOT EXISTS `cosign_requests` (
  `cr_id` int(21) NOT NULL AUTO_INCREMENT,
  `cr_agreement_id` varchar(13) NOT NULL,
  `cr_cosigner_type` varchar(20) NOT NULL,
  `cr_phone` varchar(200) NOT NULL,
  `cr_code` varchar(6) NOT NULL,
  `cr_user_id` int(21) DEFAULT NULL,
  `has_accepted` smallint(1) NOT NULL DEFAULT 0,
  `acceptance_date` datetime DEFAULT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`cr_id`),
  UNIQUE KEY `agreement_secret` (`cr_agreement_id`,`cr_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cosign_requests`
--

INSERT INTO `cosign_requests` (`cr_id`, `cr_agreement_id`, `cr_cosigner_type`, `cr_phone`, `cr_code`, `cr_user_id`, `has_accepted`, `acceptance_date`, `created_on`) VALUES
(1, '1704356349004', 'CO-APPLICANT', 'XWykVEkdSpXgSP003YsXCg==', '8DQQRG', 2, 1, '2024-01-04 13:51:56', '2024-01-04 13:50:51'),
(6, '1704356349004', 'WITNESS-1', 'BKO9Hc1AgmltgpFYwQpOqg==', '4NPKKX', 3, 1, '2024-01-04 15:04:31', '2024-01-04 14:58:26'),
(7, '1704356349004', 'WITNESS-2', 's7BR8KweJC0CgQ5OLhxmoA==', 'PK7WV4', 4, 1, '2024-01-04 15:09:59', '2024-01-04 14:58:26'),
(8, '1704446022736', 'CO-APPLICANT', '4qRNFTOmtikgNQEdiDHEoA==', 'M57337', 1, 1, '2024-01-05 15:10:23', '2024-01-05 14:50:41'),
(9, '1704446022736', 'WITNESS-1', 'BKO9Hc1AgmltgpFYwQpOqg==', '4699SW', 3, 1, '2024-01-05 15:13:21', '2024-01-05 15:11:08'),
(10, '1704446022736', 'WITNESS-2', 'XWykVEkdSpXgSP003YsXCg==', '9SKJ7C', 2, 1, '2024-01-05 15:14:34', '2024-01-05 15:11:08'),
(11, '1704692878582', 'CO-APPLICANT', 'REp/i0s9FaT4gTOMsbvvxA==', 'Q57WT4', 1, 1, '2024-01-08 11:23:32', '2024-01-08 11:22:00'),
(12, '1704692878582', 'WITNESS-1', 'BKO9Hc1AgmltgpFYwQpOqg==', 'PZB2VC', 3, 1, '2024-01-08 11:28:56', '2024-01-08 11:26:40'),
(13, '1704692878582', 'WITNESS-2', '3bacOB2VNRfIMzxu5a0H+Q==', 'ZN5HMN', 4, 1, '2024-01-08 11:30:24', '2024-01-08 11:26:40'),
(14, '1704694607491', 'CO-APPLICANT', 'pQKW6+ocopmzMAS+Vfmddw==', '5QK5T6', 5, 1, '2024-01-08 11:53:02', '2024-01-08 11:50:39'),
(15, '1704694607491', 'WITNESS-1', 'QpoUBVJcWFHY2z093mlrfg==', 'V9RD34', 6, 1, '2024-01-08 11:57:12', '2024-01-08 11:56:10'),
(16, '1704694607491', 'WITNESS-2', 'XWykVEkdSpXgSP003YsXCg==', 'P7QS4D', 2, 1, '2024-01-08 11:58:26', '2024-01-08 11:56:10'),
(17, '1704886044690', 'CO-APPLICANT', 'U+kLzYJugsPsZuzbfqIvjQ==', 'C577PB', 7, 1, '2024-01-10 17:05:54', '2024-01-10 17:00:19'),
(18, '1704886044690', 'WITNESS-1', 'pagvcWv8XW9cadSxemSJmQ==', '3TNFXG', 8, 1, '2024-01-10 17:09:01', '2024-01-10 17:07:09'),
(19, '1704886044690', 'WITNESS-2', 'MEHd3kE2enz8ASh4ghn2Iw==', 'BCPST5', NULL, 0, NULL, '2024-01-10 17:07:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(21) NOT NULL AUTO_INCREMENT,
  `user_phone` varchar(200) DEFAULT NULL,
  `user_email` varchar(200) DEFAULT NULL,
  `user_aadhaar_num` varchar(12) NOT NULL,
  `user_aadhaar_name` varchar(200) DEFAULT NULL,
  `user_aadhaar_address` text DEFAULT NULL,
  `user_aadhaar_dob` date DEFAULT NULL,
  `user_aadhaar_photo` text DEFAULT NULL,
  `user_is_udin_verified` int(11) NOT NULL DEFAULT 0,
  `user_is_active` int(11) NOT NULL DEFAULT 0,
  `user_created_on` datetime DEFAULT NULL,
  `user_updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_phone`, `user_email`, `user_aadhaar_num`, `user_aadhaar_name`, `user_aadhaar_address`, `user_aadhaar_dob`, `user_aadhaar_photo`, `user_is_udin_verified`, `user_is_active`, `user_created_on`, `user_updated_on`) VALUES
(1, '4qRNFTOmtikgNQEdiDHEoA==', NULL, 'XXXXXXXX7914', 'SANJOY CHOWDHURY', 'A.H 51, GANAPATI PARK, KRISHNAPUR MAIN ROAD, KRISHNAPUR, NORTH 24 PARAGANAS, NORTH 24 PARGANAS, WEST BENGAL, 700102, INDIA', NULL, '', 1, 1, '2024-01-04 13:46:24', '2024-01-04 13:46:24'),
(2, 'XWykVEkdSpXgSP003YsXCg==', NULL, '', 'MD ZAFER IQBAL', 'PANCHANANTALA,SANKRAIL, DANESH SK. LANE, HAORA, HOWRAH, WEST BENGAL, 711109, INDIA', NULL, '', 1, 1, '2024-01-04 13:51:55', '2024-01-04 13:51:55'),
(3, 'BKO9Hc1AgmltgpFYwQpOqg==', NULL, '', 'SUDIP MAITY', '279, NETAJI COLONY, KOLKATA, WEST BENGAL, 700090, INDIA', NULL, '', 1, 1, '2024-01-04 15:04:30', '2024-01-04 15:04:30'),
(4, '3bacOB2VNRfIMzxu5a0H+Q==', NULL, '', 'SABYASACHI TRIPATHY', 'TAMLUK, EAST MIDNAPORE, WEST BENGAL, 721636, INDIA', NULL, '', 1, 1, '2024-01-04 15:09:58', '2024-01-04 15:09:58'),
(5, 'pQKW6+ocopmzMAS+Vfmddw==', NULL, '', 'SACHIKANTA KHATUA', 'MOHATI, KHEJURI-I, PURBA MEDINIPUR, WEST BENGAL, 721430, INDIA', NULL, '', 1, 1, '2024-01-08 11:16:48', '2024-01-08 11:16:48'),
(6, 'QpoUBVJcWFHY2z093mlrfg==', NULL, '', 'SUMAN MAJHI', 'BEGAMPUR, HOOGHLY, WEST BENGAL, 712306, INDIA', NULL, '', 1, 1, '2024-01-08 11:57:11', '2024-01-08 11:57:11'),
(7, 'U+kLzYJugsPsZuzbfqIvjQ==', NULL, 'XXXXXXXX7223', 'DIBBENDU NAG', '15, GHATMAJHI LANE, SALKIA, HAORA, WEST BENGAL, 711106, INDIA', NULL, '', 1, 1, '2024-01-10 17:05:53', '2024-01-10 17:05:53'),
(8, 'pagvcWv8XW9cadSxemSJmQ==', NULL, 'XXXXXXXX2520', 'KAUSTAV PRAMANICK', '6/2, RAJENDRA NATH SEN LANE, KOLKATA, WEST BENGAL, 700006, INDIA', NULL, '', 1, 1, '2024-01-10 17:08:59', '2024-01-10 17:08:59');

-- --------------------------------------------------------

--
-- Table structure for table `user_tokens`
--

DROP TABLE IF EXISTS `user_tokens`;
CREATE TABLE IF NOT EXISTS `user_tokens` (
  `token` varchar(32) NOT NULL,
  `generated_on` datetime NOT NULL,
  `expired_on` datetime NOT NULL,
  `user_id` int(21) NOT NULL,
  UNIQUE KEY `t_token` (`token`),
  KEY `t_token_2` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_tokens`
--

INSERT INTO `user_tokens` (`token`, `generated_on`, `expired_on`, `user_id`) VALUES
('e1b9300c6939d6e16a1dc4cd0c01cfbb', '2023-12-23 10:19:41', '2023-12-23 22:19:41', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
